const express = require("express");
const cors = require("cors");
require("dotenv").config();

const { sequelize, User, Category } = require("./models");

const app = express();

/* Porta do servidor */
app.set("port", process.env.PORT || 3000);

/* Middlewares */
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* Rota de teste */
app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "API StyleMarket a funcionar",
  });
});

/* Rotas */
const categoriaRoutes = require("./routes/categoriaRoute");
const produtoRoutes = require("./routes/produtoRoute");
const encomendaRoutes = require("./routes/encomendaRoute");

app.use("/categorias", categoriaRoutes);
app.use("/produtos", produtoRoutes);
app.use("/encomendas", encomendaRoutes);

/* Liga à base de dados e inicia o servidor */
sequelize
  .sync()
  .then(async () => {
    console.log("Base de dados sincronizada com sucesso.");

    const defaultCategories = [
      "T-shirts",
      "Casacos",
      "Calças",
      "Vestidos",
      "Sapatilhas",
      "Acessórios",
    ];

    for (const categoryName of defaultCategories) {
      await Category.findOrCreate({
        where: { name: categoryName },
        defaults: { name: categoryName },
      });
    }

    await User.findOrCreate({
      where: { email: "vendedor@stylemarket.com" },
      defaults: {
        name: "Vendedor Padrão",
        email: "vendedor@stylemarket.com",
        password: "1234",
        role: "vendedor",
        storeName: "Loja Padrão",
      },
    });

    console.log("Dados iniciais verificados/criados.");

    app.listen(app.get("port"), () => {
      console.log("Servidor iniciado na porta " + app.get("port"));
    });
  })
  .catch((error) => {
    console.log("Erro ao sincronizar a base de dados:", error);
  });